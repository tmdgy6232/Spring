package com.biz.dm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TipVO {

	private long t_seq;	//	NUMBER
	private String t_subject;	//	nVARCHAR2(100)
	private String t_date;	//	VARCHAR2(10)
	private String t_writer;	//	nVARCHAR2(50)
	private String t_substance;	//	nVARCHAR2(1000)

}
