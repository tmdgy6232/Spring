package com.biz.dm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AcommentVO {

	private long a_seq;	//	NUMBER
	private String a_subject;	//	nVARCHAR2(100)
	private String a_date;	//	VARCHAR2(10)
	private String a_writer;	//	nVARCHAR2(50)
	private String a_substance;	//	nVARCHAR2(1000)

}
