package com.biz.dm.model;

public class FoodVO {
	private long t_seq;	//	NUMBER
	private String t_foodname;	//	nVARCHAR2(100)
	private String t_nutrient;	//	nVARCHAR2(300)
	private int t_kcal;	//	NUMBER

}
