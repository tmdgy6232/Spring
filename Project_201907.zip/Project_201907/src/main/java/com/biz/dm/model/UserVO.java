package com.biz.dm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UserVO {
	private String u_gender;	//	VARCHAR2(10)
	private String u_age;	//	VARCHAR2(3)
	private String u_height;	//	VARCHAR2(2)
	private String u_weight;	//	VARCHAR2(3)
	private int u_kcal;	//	NUMBER

}
