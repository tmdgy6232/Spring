package com.biz.dm.dao;

public class TipDao {
	
	public TipVO insert() {
		
	}
	
}
