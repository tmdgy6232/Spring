package com.biz.dm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.biz.dm.model.TipVO;
import com.biz.dm.service.TipService;
	
	
@Controller
public class TipController {
	
	TipService tService;

	public int TipInsert(Model model, @ModelAttribute TipVO tipVO) {
		
		int ret = tService.insert(tipVO);
		
		return ret;
	}
}
