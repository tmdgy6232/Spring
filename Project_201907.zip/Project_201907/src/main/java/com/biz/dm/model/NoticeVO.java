package com.biz.dm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class NoticeVO {
	private long n_seq;	//	NUMBER
	private String n_subject;	//	nVARCHAR2(100)
	private String n_date;	//	VARCHAR2(10)
	private String n_writer;	//	nVARCHAR2(50)
	private String n_substance;	//	nVARCHAR2(1000)

}
