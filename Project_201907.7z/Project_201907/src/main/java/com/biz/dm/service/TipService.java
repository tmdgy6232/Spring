package com.biz.dm.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biz.dm.dao.TipDao;
import com.biz.dm.model.TipVO;

@Service
public class TipService {
	
	@Autowired
	TipDao tDao;

	public int insert(TipVO tipVO) {
		LocalDateTime ldt = LocalDateTime.now();
		String time = ldt.toString();
		tipVO.setT_date(time);
		
		int ret = tDao.insert(tipVO);
		
		
	}
}
