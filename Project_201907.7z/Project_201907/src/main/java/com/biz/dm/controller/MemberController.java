package com.biz.dm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MemberController {

	@RequestMapping(value = "notice", method = RequestMethod.GET)
	public String notice(Model model) {
		model.addAttribute("BODY", "NOTICE");
		return "home";
	}

	@RequestMapping(value = "controllmenu", method = RequestMethod.GET)
	public String controllMenu(Model model) {
		model.addAttribute("BODY", "CONTROLLMENU");
		return "home";
	}

	@RequestMapping(value = "tip", method = RequestMethod.GET)
	public String tip(Model model) {
		model.addAttribute("BODY", "TIP");
		return "home";
	}
	
	@RequestMapping(value = "write", method = RequestMethod.GET)
	public String wirte(Model model) {
		model.addAttribute("BODY", "WRITE");
		return "home";
	}
	@RequestMapping(value = "tip1", method = RequestMethod.GET)
	public String tip1(Model model) {
		model.addAttribute("BODY", "TIP1");
		return "home";
	}

}
