package com.biz.dm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class YesterVO {
	private String y_morning;	//	nVARCHAR2(100)
	private String y_afternoon;	//	nVARCHAR2(100)
	private String y_evening;	//	nVARCHAR2(100)

}
